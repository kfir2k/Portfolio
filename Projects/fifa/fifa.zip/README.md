Only For Studies

# FIFA Cards Squad Builder Project

Create your virtual football team with this FIFA cards 2024 squad builder. Open with Chrome using the following tags to bypass CORS checks: 

```bash
--disable-web-security --user-data-dir="[path to directory]"
