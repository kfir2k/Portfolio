import { Controller } from "./controller.js";
const initSite = new Controller();
initSite.start();
